import './App.css';

import React, { useState, useEffect } from 'react'; // Import useEffect

const initialData = {
  tickets: [
    { id: 'CAM-1', title: 'Update User Profile Page UI', tag: ['Feature request'], userId: 'usr-1', status: 'Todo', priority: 4 },
    { id: 'CAM-2', title: 'Add Multi-Language Support', tag: ['Feature Request'], userId: 'usr-2', status: 'In progress', priority: 3 },
    { id: 'CAM-3', title: 'Optimize Database Queries for Performance', tag: ['Feature Request'], userId: 'usr-2', status: 'In progress', priority: 1 },
    { id: 'CAM-4', title: 'Implement Email Notification System', tag: ['Feature Request'], userId: 'usr-1', status: 'In progress', priority: 3 },
    { id: 'CAM-5', title: 'Enhance Search Functionality', tag: ['Feature Request'], userId: 'usr-5', status: 'In progress', priority: 0 },
    { id: 'CAM-6', title: 'Third-Party Payment Gateway', tag: ['Feature Request'], userId: 'usr-2', status: 'Todo', priority: 1 },
    { id: 'CAM-7', title: 'Create Onboarding Tutorial for New Users', tag: ['Feature Request'], userId: 'usr-1', status: 'Backlog', priority: 2 },
    { id: 'CAM-8', title: 'Implement Role-Based Access Control (RBAC)', tag: ['Feature Request'], userId: 'usr-3', status: 'In progress', priority: 3 },
    { id: 'CAM-9', title: 'Upgrade Server Infrastructure', tag: ['Feature Request'], userId: 'usr-5', status: 'Todo', priority: 2 },
    { id: 'CAM-10', title: 'Conduct Security Vulnerability Assessment', tag: ['Feature Request'], userId: 'usr-4', status: 'Backlog', priority: 1 }
  ],
  users: [
    { id: 'usr-1', name: 'Anoop Sharma', available: false },
    { id: 'usr-2', name: 'Yogesh', available: true },
    { id: 'usr-3', name: 'Shankar Kumar', available: true },
    { id: 'usr-4', name: 'Ramesh', available: true },
    { id: 'usr-5', name: 'Suresh', available: true }
  ]
};

function getUserById(id, users) {
  const user = users.find((user) => user.id === id);
  return user ? user.name : 'Unknown';
}

function KanbanBoard() {
  const [tickets, setTickets] = useState(initialData.tickets);
  const [users, setUsers] = useState(initialData.users);
  const [grouping, setGrouping] = useState('status'); // default grouping by status
  const [sorting, setSorting] = useState('priority'); // default sorting by priority

  useEffect(() => {
    const savedGrouping = localStorage.getItem('grouping');
    const savedSorting = localStorage.getItem('sorting');
    if (savedGrouping) setGrouping(savedGrouping);
    if (savedSorting) setSorting(savedSorting);
  }, []);

  useEffect(() => {
    localStorage.setItem('grouping', grouping);
    localStorage.setItem('sorting', sorting);
  }, [grouping, sorting]);

  // Helper function to group tickets
  const groupBy = (items, key) => {
    return items.reduce((acc, item) => {
      const groupKey = item[key];
      if (!acc[groupKey]) {
        acc[groupKey] = [];
      }
      acc[groupKey].push(item);
      return acc;
    }, {});
  };

  const getGroupedTickets = () => {
    return groupBy(tickets, grouping);
  };

  const getSortedTickets = (tickets) => {
    // Create a new sorted array instead of modifying the original
    const sortedTickets = [...tickets];
    if (sorting === 'priority') {
      return sortedTickets.sort((a, b) => b.priority - a.priority);
    }
    return sortedTickets.sort((a, b) => a.title.localeCompare(b.title));
  };

  const groupedTickets = getGroupedTickets();
  const sortedGroupedTickets = Object.keys(groupedTickets).map((groupKey) => {
    return {
      key: groupKey,
      tickets: getSortedTickets(groupedTickets[groupKey])
    };
  });

  return (
    <div>
      <div className="controls">
        <label>Group by: </label>
        <select value={grouping} onChange={(e) => setGrouping(e.target.value)}>
          <option value="status">Status</option>
          <option value="userId">User</option>
          <option value="priority">Priority</option>
        </select>

        <label>Sort by: </label>
        <select value={sorting} onChange={(e) => setSorting(e.target.value)}>
          <option value="priority">Priority</option>
          <option value="title">Title</option>
        </select>
      </div>

      <div className="kanban-board">
        {sortedGroupedTickets.map((group) => (
          <div key={group.key} className="column">
            <h2>{group.key}</h2>
            {group.tickets.map((ticket) => (
              <div key={ticket.id} className="ticket-card">
                <h3>{ticket.title}</h3>
                <p>Priority: {ticket.priority}</p>
                <p>User: {getUserById(ticket.userId, users)}</p>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

export default KanbanBoard;
